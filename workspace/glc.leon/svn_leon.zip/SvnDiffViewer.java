import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
/*
 * Created by JFormDesigner on Thu May 21 12:22:39 CST 2015
 */



/**
 * @author Brainrain
 */
public class SvnDiffViewer extends JPanel {

	Vector<String> data = new Vector<>();

	public SvnDiffViewer() {
		initComponents();


//		list1.setListData();
	}

	private void textField1ActionPerformed(ActionEvent e) {
		try
		{
			BufferedReader in = new BufferedReader(new FileReader(textField1.getText() + "/svn_diff.txt"));
			String buf;
			ArrayList<String> list = new ArrayList<>();
			while((buf = in.readLine()) != null)
			{
				if(buf.length() >=8 && buf.substring(1).matches("       \\S+"))
				{
					list.add(buf.substring(8));
				}
				else
				{
//					System.out.println(buf);
				}
			}
			in.close();

			list1.setListData(list.toArray());
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	private void list1MouseClicked(MouseEvent e) {
		if(e.getClickCount() < 2)
		{
			return;
		}

		System.out.println(list1.getSelectedValue());

		ProcessBuilder pb = new ProcessBuilder(
			"C:\\Program Files\\TortoiseSVN\\bin\\TortoiseProc.exe",
		    "/command:diff",
		    "/path:" + textField1.getText() + "/" + list1.getSelectedValue(),
		    "/closeonend:2"
		);
		try
		{
			pb.start();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public static void main(String[] args)
		throws Exception
	{
		JFrame mf = new JFrame("SVN Diff Viewer");
		mf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		Container c = mf.getContentPane();
		c.add(new SvnDiffViewer());
		mf.setSize(500, 700);
		mf.setLocationRelativeTo(null);
		mf.setVisible(true);
	}

	private void button1ActionPerformed(ActionEvent e)
	{
		textField1ActionPerformed(null);
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		scrollPane1 = new JScrollPane();
		list1 = new JList();
		textField1 = new JTextField();
		button1 = new JButton();

		//======== this ========

		//======== scrollPane1 ========
		{

			//---- list1 ----
			list1.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					list1MouseClicked(e);
				}
			});
			scrollPane1.setViewportView(list1);
		}

		//---- textField1 ----
		textField1.setText("Y:\\workspace\\glc1440x55");
		textField1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				textField1ActionPerformed(e);
			}
		});

		//---- button1 ----
		button1.setText("Scan");
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				button1ActionPerformed(e);
			}
		});

		GroupLayout layout = new GroupLayout(this);
		setLayout(layout);
		layout.setHorizontalGroup(
			layout.createParallelGroup()
				.addGroup(layout.createSequentialGroup()
					.addContainerGap()
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
						.addComponent(scrollPane1)
						.addGroup(layout.createSequentialGroup()
							.addComponent(textField1, GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
							.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
							.addComponent(button1, GroupLayout.PREFERRED_SIZE, 137, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		layout.setVerticalGroup(
			layout.createParallelGroup()
				.addGroup(layout.createSequentialGroup()
					.addContainerGap()
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
						.addComponent(textField1)
						.addComponent(button1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
					.addComponent(scrollPane1, GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE)
					.addContainerGap())
		);
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	private JScrollPane scrollPane1;
	private JList list1;
	private JTextField textField1;
	private JButton button1;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
