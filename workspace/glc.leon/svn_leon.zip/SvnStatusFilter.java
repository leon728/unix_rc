import java.io.*;
import java.util.*;

/**
 * User: leon
 * Date: 2015/05/21
 */
public class SvnStatusFilter
{
	public static void main(String[] args)
		throws Exception
	{
		ArrayList<String> ignoreList_startWith = new ArrayList<String>();
		ArrayList<String> ignoreList_contain = new ArrayList<String>();

		File f_ignore = new File("svn_ignore.txt");
		{
			BufferedReader in = new BufferedReader(new FileReader(f_ignore));
			String buf;
			while((buf = in.readLine()) != null)
			{
				buf = buf.trim();
				if(buf.length() == 0 || buf.charAt(0) == '#') {
					continue;
				}

				if(buf.charAt(0) == '*') {
					ignoreList_contain.add(buf.substring(2));
				}
				else {
					ignoreList_startWith.add(buf);
				}
			}
			in.close();
		}

		File f_ss = new File("svn_status.txt");
		BufferedReader in;
		String buf;

		ArrayList<String> tmpOut = new ArrayList<>();

		in = new BufferedReader(new FileReader(f_ss));
		while((buf = in.readLine()) != null)
		{
			boolean show = true;

			if(buf.length() >= 8)
			{
				String tmpStr = buf.substring(8);

				for(String str : ignoreList_startWith)
				{
					if(tmpStr.startsWith(str))
					{
						show = false;
						break;
					}
				}

				for(String str : ignoreList_contain)
				{
					if(tmpStr.contains(str))
					{
						show = false;
						break;
					}
				}

				if( buf.endsWith(".d") ||
					buf.endsWith(".o"))
				{
					show = false;
				}

				if(show && buf.contains("cmapi_")) {
					if(buf.endsWith(".c")) {

					}
					else if(buf.endsWith(".h")) {

					}
				}
			}

			if(show)
			{
//				System.out.println(buf);
				tmpOut.add(buf);
			}
		}
		in.close();

		for(int i = 0; i < tmpOut.size(); i++)
		{
			String str = tmpOut.get(i);
			if(str.contains("/cmapi_") && str.endsWith(".c") && i+1 < tmpOut.size()) {
				String next = tmpOut.get(i + 1);
				if(next.contains(str.substring(0, str.length() - 2)) && next.endsWith(".h")) {
					i++;
					continue;
				}
			}
			System.out.println(str);
		}
	}
}
